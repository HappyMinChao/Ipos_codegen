package com.publicpay.account.beans.bo;

import java.io.Serializable;
import java.util.Date;

public class JpushMsg implements Serializable {
    private String id;

    private String accountNo;

    private String app;

    private String jpushId;

    private String msgGroup;

    private String product;

    private String priority;

    private String title;

    private String pushBarTxt;

    private Byte centerShow;

    private Date planTime;

    private Date planOktime;

    private String sendStatus;

    private String failReason;

    private Date sendTime;

    private String readStatus;

    private Long announceId;

    private String redirectParams;

    private Date createTime;

    private String createUser;

    private String updateUser;

    private Date updateTime;

    private Long version;

    private String contentTxt;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo == null ? null : accountNo.trim();
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app == null ? null : app.trim();
    }

    public String getJpushId() {
        return jpushId;
    }

    public void setJpushId(String jpushId) {
        this.jpushId = jpushId == null ? null : jpushId.trim();
    }

    public String getMsgGroup() {
        return msgGroup;
    }

    public void setMsgGroup(String msgGroup) {
        this.msgGroup = msgGroup == null ? null : msgGroup.trim();
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product == null ? null : product.trim();
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority == null ? null : priority.trim();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    public String getPushBarTxt() {
        return pushBarTxt;
    }

    public void setPushBarTxt(String pushBarTxt) {
        this.pushBarTxt = pushBarTxt == null ? null : pushBarTxt.trim();
    }

    public Byte getCenterShow() {
        return centerShow;
    }

    public void setCenterShow(Byte centerShow) {
        this.centerShow = centerShow;
    }

    public Date getPlanTime() {
        return planTime;
    }

    public void setPlanTime(Date planTime) {
        this.planTime = planTime;
    }

    public Date getPlanOktime() {
        return planOktime;
    }

    public void setPlanOktime(Date planOktime) {
        this.planOktime = planOktime;
    }

    public String getSendStatus() {
        return sendStatus;
    }

    public void setSendStatus(String sendStatus) {
        this.sendStatus = sendStatus == null ? null : sendStatus.trim();
    }

    public String getFailReason() {
        return failReason;
    }

    public void setFailReason(String failReason) {
        this.failReason = failReason == null ? null : failReason.trim();
    }

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }

    public String getReadStatus() {
        return readStatus;
    }

    public void setReadStatus(String readStatus) {
        this.readStatus = readStatus == null ? null : readStatus.trim();
    }

    public Long getAnnounceId() {
        return announceId;
    }

    public void setAnnounceId(Long announceId) {
        this.announceId = announceId;
    }

    public String getRedirectParams() {
        return redirectParams;
    }

    public void setRedirectParams(String redirectParams) {
        this.redirectParams = redirectParams == null ? null : redirectParams.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser == null ? null : createUser.trim();
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser == null ? null : updateUser.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public String getContentTxt() {
        return contentTxt;
    }

    public void setContentTxt(String contentTxt) {
        this.contentTxt = contentTxt == null ? null : contentTxt.trim();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        JpushMsg other = (JpushMsg) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getAccountNo() == null ? other.getAccountNo() == null : this.getAccountNo().equals(other.getAccountNo()))
            && (this.getApp() == null ? other.getApp() == null : this.getApp().equals(other.getApp()))
            && (this.getJpushId() == null ? other.getJpushId() == null : this.getJpushId().equals(other.getJpushId()))
            && (this.getMsgGroup() == null ? other.getMsgGroup() == null : this.getMsgGroup().equals(other.getMsgGroup()))
            && (this.getProduct() == null ? other.getProduct() == null : this.getProduct().equals(other.getProduct()))
            && (this.getPriority() == null ? other.getPriority() == null : this.getPriority().equals(other.getPriority()))
            && (this.getTitle() == null ? other.getTitle() == null : this.getTitle().equals(other.getTitle()))
            && (this.getPushBarTxt() == null ? other.getPushBarTxt() == null : this.getPushBarTxt().equals(other.getPushBarTxt()))
            && (this.getCenterShow() == null ? other.getCenterShow() == null : this.getCenterShow().equals(other.getCenterShow()))
            && (this.getPlanTime() == null ? other.getPlanTime() == null : this.getPlanTime().equals(other.getPlanTime()))
            && (this.getPlanOktime() == null ? other.getPlanOktime() == null : this.getPlanOktime().equals(other.getPlanOktime()))
            && (this.getSendStatus() == null ? other.getSendStatus() == null : this.getSendStatus().equals(other.getSendStatus()))
            && (this.getFailReason() == null ? other.getFailReason() == null : this.getFailReason().equals(other.getFailReason()))
            && (this.getSendTime() == null ? other.getSendTime() == null : this.getSendTime().equals(other.getSendTime()))
            && (this.getReadStatus() == null ? other.getReadStatus() == null : this.getReadStatus().equals(other.getReadStatus()))
            && (this.getAnnounceId() == null ? other.getAnnounceId() == null : this.getAnnounceId().equals(other.getAnnounceId()))
            && (this.getRedirectParams() == null ? other.getRedirectParams() == null : this.getRedirectParams().equals(other.getRedirectParams()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getCreateUser() == null ? other.getCreateUser() == null : this.getCreateUser().equals(other.getCreateUser()))
            && (this.getUpdateUser() == null ? other.getUpdateUser() == null : this.getUpdateUser().equals(other.getUpdateUser()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getVersion() == null ? other.getVersion() == null : this.getVersion().equals(other.getVersion()))
            && (this.getContentTxt() == null ? other.getContentTxt() == null : this.getContentTxt().equals(other.getContentTxt()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getAccountNo() == null) ? 0 : getAccountNo().hashCode());
        result = prime * result + ((getApp() == null) ? 0 : getApp().hashCode());
        result = prime * result + ((getJpushId() == null) ? 0 : getJpushId().hashCode());
        result = prime * result + ((getMsgGroup() == null) ? 0 : getMsgGroup().hashCode());
        result = prime * result + ((getProduct() == null) ? 0 : getProduct().hashCode());
        result = prime * result + ((getPriority() == null) ? 0 : getPriority().hashCode());
        result = prime * result + ((getTitle() == null) ? 0 : getTitle().hashCode());
        result = prime * result + ((getPushBarTxt() == null) ? 0 : getPushBarTxt().hashCode());
        result = prime * result + ((getCenterShow() == null) ? 0 : getCenterShow().hashCode());
        result = prime * result + ((getPlanTime() == null) ? 0 : getPlanTime().hashCode());
        result = prime * result + ((getPlanOktime() == null) ? 0 : getPlanOktime().hashCode());
        result = prime * result + ((getSendStatus() == null) ? 0 : getSendStatus().hashCode());
        result = prime * result + ((getFailReason() == null) ? 0 : getFailReason().hashCode());
        result = prime * result + ((getSendTime() == null) ? 0 : getSendTime().hashCode());
        result = prime * result + ((getReadStatus() == null) ? 0 : getReadStatus().hashCode());
        result = prime * result + ((getAnnounceId() == null) ? 0 : getAnnounceId().hashCode());
        result = prime * result + ((getRedirectParams() == null) ? 0 : getRedirectParams().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getCreateUser() == null) ? 0 : getCreateUser().hashCode());
        result = prime * result + ((getUpdateUser() == null) ? 0 : getUpdateUser().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getVersion() == null) ? 0 : getVersion().hashCode());
        result = prime * result + ((getContentTxt() == null) ? 0 : getContentTxt().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", accountNo=").append(accountNo);
        sb.append(", app=").append(app);
        sb.append(", jpushId=").append(jpushId);
        sb.append(", msgGroup=").append(msgGroup);
        sb.append(", product=").append(product);
        sb.append(", priority=").append(priority);
        sb.append(", title=").append(title);
        sb.append(", pushBarTxt=").append(pushBarTxt);
        sb.append(", centerShow=").append(centerShow);
        sb.append(", planTime=").append(planTime);
        sb.append(", planOktime=").append(planOktime);
        sb.append(", sendStatus=").append(sendStatus);
        sb.append(", failReason=").append(failReason);
        sb.append(", sendTime=").append(sendTime);
        sb.append(", readStatus=").append(readStatus);
        sb.append(", announceId=").append(announceId);
        sb.append(", redirectParams=").append(redirectParams);
        sb.append(", createTime=").append(createTime);
        sb.append(", createUser=").append(createUser);
        sb.append(", updateUser=").append(updateUser);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", version=").append(version);
        sb.append(", contentTxt=").append(contentTxt);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}