package com.publicpay.account.mapper;

import com.publicpay.account.beans.bo.JpushMsg;

public interface JpushMsgMapper {
    int deleteByPrimaryKey(String id);

    int insert(JpushMsg record);

    int insertSelective(JpushMsg record);

    JpushMsg selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(JpushMsg record);

    int updateByPrimaryKeyWithBLOBs(JpushMsg record);

    int updateByPrimaryKey(JpushMsg record);
}