package com.publicpay.account.mapper;

import com.publicpay.account.beans.bo.MsgGroup;

public interface MsgGroupMapper {
    int deleteByPrimaryKey(String id);

    int insert(MsgGroup record);

    int insertSelective(MsgGroup record);

    MsgGroup selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(MsgGroup record);

    int updateByPrimaryKey(MsgGroup record);
}