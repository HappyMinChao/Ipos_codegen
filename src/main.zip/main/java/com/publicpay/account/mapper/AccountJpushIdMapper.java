package com.publicpay.account.mapper;

import com.publicpay.account.beans.bo.AccountJpushId;

public interface AccountJpushIdMapper {
    int insert(AccountJpushId record);

    int insertSelective(AccountJpushId record);
}